class InvalidVersionError(Exception):
    pass


class CompilationError(Exception):
    pass


class InvalidToolchainError(Exception):
    pass
